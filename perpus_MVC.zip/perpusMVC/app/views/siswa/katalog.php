<!DOCTYPE html>
<html lang="id">
<head>
    <title>Katalog Buku</title>
    <link rel="stylesheet" href="public/css/bootstrap.min.css">
</head>
<body class="bg-light">
    <div class="container mt-5 mb-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>📚 Katalog Buku</h2>
            <a href="index.php?controller=siswa&action=dashboard" class="btn btn-secondary">Kembali</a>
        </div>

        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <form method="GET" action="" class="d-flex gap-2">
                    <input type="hidden" name="controller" value="siswa">
                    <input type="hidden" name="action" value="katalog">
                    <input type="text" name="cari" class="form-control form-control-lg" placeholder="Cari judul buku atau pengarang..." value="<?= isset($_GET['cari']) ? $_GET['cari'] : '' ?>">
                    <button type="submit" class="btn btn-primary btn-lg">Cari</button>
                </form>
            </div>
        </div>

        <div class="card shadow-sm border-0">
            <div class="card-body p-0">
                <table class="table table-hover table-striped mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th class="p-3">Judul Buku</th>
                            <th class="p-3">Pengarang</th>
                            <th class="p-3 text-center">Stok</th>
                            <th class="p-3 text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = mysqli_fetch_assoc($data_buku)) { ?>
                        <tr>
                            <td class="p-3 fw-bold"><?= $row['judul']; ?></td>
                            <td class="p-3"><?= $row['pengarang']; ?></td>
                            <td class="p-3 text-center">
                                <?php if($row['stok'] > 0) { ?>
                                    <span class="badge bg-success"><?= $row['stok']; ?> Tersedia</span>
                                <?php } else { ?>
                                    <span class="badge bg-danger">Habis</span>
                                <?php } ?>
                            </td>
                            <td class="p-3 text-center">
                                <a href="index.php?controller=siswa&action=detail_buku&id=<?= $row['id_buku']; ?>" class="btn btn-info btn-sm text-white">Lihat Detail</a>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>