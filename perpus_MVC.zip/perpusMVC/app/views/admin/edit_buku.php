<!DOCTYPE html>
<html>
<head>
    <title>Edit Buku</title>
    <link rel="stylesheet" href="public/css/bootstrap.min.css">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card shadow-sm border-0 col-md-8 mx-auto">
            <div class="card-header bg-warning text-dark py-3">
                <h4 class="mb-0 fw-bold">✏️ Edit Data Buku</h4>
            </div>
            <div class="card-body p-4">
                <form method="POST" action="">
                    <input type="hidden" name="id_buku" value="<?= $data['id_buku']; ?>">

                    <div class="mb-3">
                        <label class="fw-bold">Judul Buku</label>
                        <input type="text" name="judul" class="form-control" value="<?= $data['judul']; ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="fw-bold">Pengarang</label>
                        <input type="text" name="pengarang" class="form-control" value="<?= $data['pengarang']; ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="fw-bold">Penerbit</label>
                        <input type="text" name="penerbit" class="form-control" value="<?= $data['penerbit']; ?>" required>
                    </div>

                    <div class="mb-4">
                        <label class="fw-bold">Sisa Stok</label>
                        <input type="number" name="stok" class="form-control" value="<?= $data['stok']; ?>" 
                               min="0" 
                               oninput="this.value = this.value.replace(/^0+(?=\d)/, '');" 
                               onblur="if(this.value=='') this.value='0';" 
                               required>
                        <div class="form-text text-muted">
                            <small>Pastikan stok buku sama dengan jumlah yang tersedia.</small>
                        </div>
                    </div>

                    <hr class="mt-4 mb-4">

                    <div class="d-flex justify-content-between">
                        <a href="index.php?controller=admin&action=kelola_buku" class="btn btn-secondary px-4">⬅ Batal</a>
                        <button type="submit" name="update" class="btn btn-primary px-4">💾 Simpan Perubahan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>