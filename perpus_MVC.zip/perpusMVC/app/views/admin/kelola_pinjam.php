<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Peminjaman | Admin</title>
    <link rel="stylesheet" href="public/css/bootstrap.min.css">
</head>
<body class="bg-light">
                
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3>🤝 Data Peminjaman</h3>
                    <a href="index.php?controller=admin&action=dashboard" class="btn btn-secondary">
                        ⬅ Kembali ke Dashboard
                    </a>
        </div>
            <a href="index.php?controller=admin&action=tambah_pinjam" class="btn btn-success">+ Tambah Peminjaman</a>

        <div class="card shadow-sm border-0">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover text-center align-middle">
                        <thead class="table-dark">
                            <tr>
                                <th>No</th>
                                <th>Nama Peminjam</th>
                                <th>Judul Buku</th>
                                <th>Tanggal Pinjam</th>
                                <th>Tanggal Kembali</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            // Mengecek apakah ada data transaksi
                            if (!empty($data_transaksi)) {
                                $no = 1;
                                foreach ($data_transaksi as $row) { 
                            ?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td class="text-start"><?= $row['nama_lengkap']; ?></td>
                                    <td class="text-start"><?= $row['judul']; ?></td>
                                    <td><?= $row['tanggal_pinjam']; ?></td>
                                    
                                    <td>
                                        <?= ($row['tanggal_kembali'] != '0000-00-00' && $row['tanggal_kembali'] != null) ? $row['tanggal_kembali'] : '<span class="text-muted">Belum dikembalikan</span>'; ?>
                                    </td>
                                    
                                    <td>
                                        <?php if ($row['status'] == 'dipinjam') { ?>
                                            <span class="badge bg-warning text-dark">Dipinjam</span>
                                        <?php } else { ?>
                                            <span class="badge bg-success">Dikembalikan</span>
                                        <?php } ?>
                                    </td>
                                    
                                    <td>
                                        <?php if ($row['status'] == 'dipinjam') { ?>
                                            <a href="index.php?controller=admin&action=proses_kembali&id=<?= $row['id_transaksi']; ?>&id_buku=<?= $row['id_buku']; ?>" 
                                               class="btn btn-sm btn-info text-white" 
                                               onclick="return confirm('Konfirmasi pengembalian buku ini?')">
                                               Kembalikan
                                            </a>
                                        <?php } else { ?>
                                            <button class="btn btn-sm btn-secondary" disabled>Selesai</button>
                                        <?php } ?>
                                    </td>
                                </tr>
                            <?php 
                                } 
                            } else { 
                            ?>
                                <tr>
                                    <td colspan="7" class="text-center py-3 text-muted">Belum ada data transaksi peminjaman.</td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
