<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Form Peminjaman Buku</title>
    <link rel="stylesheet" href="public/css/bootstrap.min.css">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card shadow-sm col-md-6 mx-auto border-0">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0">Form Peminjaman Buku</h5>
            </div>
            <div class="card-body">
                <form action="index.php?controller=admin&action=tambah_pinjam" method="POST">
                    
                    <div class="mb-3">
                        <label class="fw-bold">Pilih Peminjam</label>
                        <select name="id_user" class="form-select" required>
                            <option value="">-- Pilih Anggota --</option>
                            <?php foreach($data_user as $u): ?>
                                <?php if($u['role'] == 'siswa'): ?>
                                    <option value="<?= $u['id_user'] ?>">
                                        <?= $u['nama_lengkap'] ?>
                                    </option>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="fw-bold">Pilih Buku</label>
                        <select name="id_buku" class="form-select" required>
                            <option value="">-- Pilih Buku yang Ingin Dipinjam --</option>
                            <?php foreach($data_buku as $b): ?>
                                <option value="<?= $b['id_buku'] ?>" <?= ($b['stok'] <= 0) ? 'disabled' : '' ?>>
                                    <?= $b['judul'] ?> (Sisa Stok: <?= $b['stok'] ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-4">
                        <label class="fw-bold">Tanggal Pinjam</label>
                        <input type="date" name="tanggal_pinjam" class="form-control" value="<?= date('Y-m-d') ?>" required>
                    </div>

                    <div class="d-flex justify-content-between">
                        <a href="index.php?controller=admin&action=kelola_pinjam" class="btn btn-secondary">Kembali</a>
                        <button type="submit" name="simpan_pinjam" class="btn btn-success">Simpan & Pinjam</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>