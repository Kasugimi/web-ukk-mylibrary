<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Peminjaman</title>
    <link rel="stylesheet" href="public/css/bootstrap.min.css">
</head>
<body class="bg-light">

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6"> 
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-warning text-dark py-3">
                        <h4 class="mb-0 fw-bold">✏️ Edit Data Peminjaman</h4>
                    </div>
                    
                    <div class="card-body p-4">
                        <div class="alert alert-info pb-2 pt-3 mb-4">
                            <small>Pastikan perubahan tanggal sesuai dengan catatan fisik perpustakaan.</small>
                        </div>

                        <form method="POST" action="">
                            <input type="hidden" name="id_transaksi" value="<?= $data['id_transaksi']; ?>">
                            
                            <input type="hidden" name="status" value="<?= $data['status']; ?>">

                            <div class="mb-3">
                                <label class="form-label fw-bold">Tanggal Pinjam</label>
                                <input type="date" name="tanggal_pinjam" class="form-control" value="<?= $data['tanggal_pinjam']; ?>" required>
                            </div>

                            <div class="mb-4">
                                <label class="form-label fw-bold">Tanggal Kembali</label>
                                <input type="date" name="tanggal_kembali" class="form-control" value="<?= $data['tanggal_kembali']; ?>">
                                <div class="form-text text-muted">
                                    <em>Biarkan kosong jika buku belum dikembalikan.</em>
                                </div>
                            </div>

                            <hr class="mt-4 mb-4">

                            <div class="d-flex justify-content-between">
                                <a href="index.php?controller=admin&action=laporan" class="btn btn-secondary px-4">
                                    ⬅ Batal
                                </a>
                                <button type="submit" name="update" class="btn btn-primary px-4">
                                    💾 Simpan Perubahan
                                </button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html>