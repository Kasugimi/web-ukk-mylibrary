<!DOCTYPE html>
<html lang="id">
<head>
    <title>Kelola Data Buku</title>
    <link rel="stylesheet" href="public/css/bootstrap.min.css">
</head>
<body class="bg-light">
    <div class="container mt-5 mb-5">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3>📖 Kelola Data Buku</h3>
            <a href="index.php?controller=admin&action=dashboard" class="btn btn-secondary">⬅ Kembali ke Dashboard</a>
        </div>

        <div class="row">
            <div class="col-md-4">
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Tambah Buku Baru</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label>Judul Buku</label>
                                <input type="text" name="judul" class="form-control" required placeholder="Contoh: Pemrograman PHP">
                            </div>
                            <div class="mb-3">
                                <label>Pengarang</label>
                                <input type="text" name="pengarang" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label>Penerbit</label>
                                <input type="text" name="penerbit" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label>Stok</label>
                                <input type="number" name="stok" class="form-control" required min="1">
                            </div>
                            <button type="submit" name="tambah" class="btn btn-success w-100">Simpan Buku</button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover table-bordered">
                                <thead class="table-dark text-center">
                                    <tr>
                                        <th>No</th>
                                        <th>Judul</th>
                                        <th>Pengarang</th>
                                        <th>Stok</th>
                                        <th width="150">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $no = 1;
                                    while($row = mysqli_fetch_assoc($data_buku)) { ?>
                                    <tr>
                                        <td class="text-center"><?= $no++; ?></td>
                                        <td><?= $row['judul']; ?></td>
                                        <td><?= $row['pengarang']; ?></td>
                                        <td class="text-center">
                                            <span class="badge bg-info text-dark"><?= $row['stok']; ?></span>
                                        </td>
                                        <td class="text-center">
                                            <a href="index.php?controller=admin&action=edit_buku&id=<?= $row['id_buku']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                            <a href="index.php?controller=admin&action=kelola_buku&hapus_id=<?= $row['id_buku']; ?>" onclick="return confirm('Hapus?')" class="btn btn-danger btn-sm">Hapus</a>
                                        </td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>