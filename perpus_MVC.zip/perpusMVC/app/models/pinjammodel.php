<?php

class PinjamModel {
    private $db;

    public function __construct() {
        $this->db = new Database();
    }

    // =========================================================
    // 1. TAMPIL SEMUA DATA PEMINJAMAN (ADMIN)
    // =========================================================
    public function getAllTransaksi() {
        $query = "SELECT pinjam.*, users.nama_lengkap, buku.judul 
                  FROM pinjam 
                  JOIN users ON pinjam.id_user = users.id_user 
                  JOIN buku ON pinjam.id_buku = buku.id_buku 
                  ORDER BY pinjam.tanggal_pinjam DESC";
                  
        $result = mysqli_query($this->db->koneksi, $query); 
        if (!$result) die("Error Tampil Data: " . mysqli_error($this->db->koneksi));
        
        $data = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = $row;
        }
        return $data;
    }

    // =========================================================
    // 2. SIMPAN PEMINJAMAN BARU (ADMIN)
    // =========================================================
    public function tambahPinjam($data) {
        $id_user = $data['id_user'];
        $id_buku = $data['id_buku'];
        $tanggal_pinjam = $data['tanggal_pinjam'];

        $query = "INSERT INTO pinjam (id_user, id_buku, tanggal_pinjam, status) 
                  VALUES ('$id_user', '$id_buku', '$tanggal_pinjam', 'dipinjam')";
        
        $insert = mysqli_query($this->db->koneksi, $query);
        if (!$insert) die("Error Simpan Admin: " . mysqli_error($this->db->koneksi));

        // Kurangi stok buku (-1)
        $queryStok = "UPDATE buku SET stok = stok - 1 WHERE id_buku = '$id_buku'";
        mysqli_query($this->db->koneksi, $queryStok);
        return true;
    }

    // =========================================================
    // 3. PROSES PENGEMBALIAN BUKU
    // =========================================================
    public function kembalikanBuku($id_transaksi, $id_buku) {
        $tanggal_kembali = date('Y-m-d');
        
        // CATATAN: Pastikan nama kolom primary key-nya id_transaksi atau id_pinjam
        $query = "UPDATE pinjam SET tanggal_kembali = '$tanggal_kembali', status = 'kembali' 
                  WHERE id_transaksi = '$id_transaksi'";
        
        $update = mysqli_query($this->db->koneksi, $query);
        if (!$update) die("Error Kembalikan Buku: " . mysqli_error($this->db->koneksi));

        // Tambah stok buku (+1)
        $queryStok = "UPDATE buku SET stok = stok + 1 WHERE id_buku = '$id_buku'";
        mysqli_query($this->db->koneksi, $queryStok);
        return true;
    }

    // =========================================================
    // 4. AMBIL DATA UNTUK LAPORAN
    // =========================================================
    public function getLaporan($tgl_awal = '', $tgl_akhir = '') {
        $query = "SELECT pinjam.*, users.nama_lengkap, buku.judul 
                  FROM pinjam 
                  JOIN users ON pinjam.id_user = users.id_user 
                  JOIN buku ON pinjam.id_buku = buku.id_buku";
        
        if ($tgl_awal != '' && $tgl_akhir != '') {
            $query .= " WHERE pinjam.tanggal_pinjam BETWEEN '$tgl_awal' AND '$tgl_akhir'";
        }
        
        $query .= " ORDER BY pinjam.tanggal_pinjam DESC";

        $result = mysqli_query($this->db->koneksi, $query);
        if (!$result) die("Error Laporan: " . mysqli_error($this->db->koneksi));

        $data = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = $row;
        }
        return $data;
    }

    // =========================================================
    // 5. AMBIL SATU DATA UNTUK FORM EDIT
    // =========================================================
    public function getPinjamById($id) {
        $query = "SELECT pinjam.*, users.nama_lengkap, buku.judul 
                  FROM pinjam 
                  JOIN users ON pinjam.id_user = users.id_user 
                  JOIN buku ON pinjam.id_buku = buku.id_buku 
                  WHERE pinjam.id_transaksi = '$id'";
                  
        $result = mysqli_query($this->db->koneksi, $query);
        return mysqli_fetch_assoc($result);
    }

    // =========================================================
    // 6. UPDATE / SIMPAN HASIL EDIT
    // =========================================================
    public function updatePinjam($data) {
        $id_transaksi = $data['id_transaksi'];
        $tanggal_kembali = $data['tanggal_kembali'];
        $status = $data['status'];

        $query = "UPDATE pinjam SET 
                  tanggal_kembali = '$tanggal_kembali', 
                  status = '$status' 
                  WHERE id_transaksi = '$id_transaksi'";
                  
        return mysqli_query($this->db->koneksi, $query);
    }

    // =========================================================
    // 7. HAPUS RIWAYAT PEMINJAMAN
    // =========================================================
    public function hapusPinjam($id) {
        $query = "DELETE FROM pinjam WHERE id_transaksi = '$id'";
        return mysqli_query($this->db->koneksi, $query);
    }

    // =========================================================
    // 8. FUNGSI UNTUK SISWA: Mengambil riwayat pinjam milik sendiri
    // =========================================================
    public function getRiwayatSiswa($id_user) {
        $id = mysqli_real_escape_string($this->db->koneksi, $id_user);
        
        $query = "SELECT pinjam.*, buku.judul 
                  FROM pinjam 
                  JOIN buku ON pinjam.id_buku = buku.id_buku 
                  WHERE pinjam.id_user = '$id' 
                  ORDER BY pinjam.tanggal_pinjam DESC";
                  
        $result = mysqli_query($this->db->koneksi, $query);
        if (!$result) die("Error Riwayat: " . mysqli_error($this->db->koneksi));
        
        $data = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = $row;
        }
        return $data;
    }

    // =========================================================
    // 9. FUNGSI UNTUK SISWA: Meminjam buku dari Pop-Up
    // =========================================================
    public function pinjamBuku($id_user, $id_buku, $tanggal_pinjam = null) {
        if ($tanggal_pinjam === null) {
            $tanggal_pinjam = date('Y-m-d');
        }

        $id_u = mysqli_real_escape_string($this->db->koneksi, $id_user);
        $id_b = mysqli_real_escape_string($this->db->koneksi, $id_buku);
        
        $query = "INSERT INTO pinjam (id_user, id_buku, tanggal_pinjam, status) 
                  VALUES ('$id_u', '$id_b', '$tanggal_pinjam', 'dipinjam')";
        
        $insert = mysqli_query($this->db->koneksi, $query);

        // Alat deteksi error
        if (!$insert) {
            die("GAGAL MENYIMPAN TRANSAKSI! Error Database: " . mysqli_error($this->db->koneksi));
        }

        // Kurangi stok buku (-1)
        $queryStok = "UPDATE buku SET stok = stok - 1 WHERE id_buku = '$id_b'";
        mysqli_query($this->db->koneksi, $queryStok);
        return true;
    }

// =========================================================
    // 10. CEK STATUS BUKU SEBELUM DIHAPUS (INTEGRITAS DATA)
    // =========================================================
    public function cekBukuDipinjam($id_buku) {
        $query = "SELECT * FROM pinjam WHERE id_buku = '$id_buku' AND status = 'dipinjam'";
        
        // BAGIAN YANG DIPERBAIKI: Menggunakan $this->db->koneksi
        $result = mysqli_query($this->db->koneksi, $query);
        
        // Alat deteksi error
        if (!$result) {
            die("Error Cek Buku: " . mysqli_error($this->db->koneksi));
        }
        
        if (mysqli_num_rows($result) > 0) {
            return true;  // TRUE: Buku sedang dipinjam
        } else {
            return false; // FALSE: Buku aman untuk dihapus
        }
    }
    
    }

?>