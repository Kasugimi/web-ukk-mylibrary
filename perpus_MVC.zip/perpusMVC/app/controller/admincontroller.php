<?php
require_once __DIR__ . '/../models/BukuModel.php';
require_once __DIR__ . '/../models/PinjamModel.php';
require_once __DIR__ . '/../models/UserModel.php';


class AdminController {
    
    // Properti database (opsional, tergantung struktur aplikasimu)
    public $db; 

    public function __construct() {
        if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
            header("Location: index.php?controller=auth&action=login");
            exit;
        }
        
        // CATATAN: Jika kamu punya file koneksi database terpusat, pastikan variabel $koneksi
        // dihubungkan ke $this->db di sini. Jika tidak, hapus saja parameter di TransaksiModel nanti.
        global $koneksi; 
        if(isset($koneksi)) {
            $this->db = $koneksi;
        }
    }

    // Action 1: Dashboard
    public function dashboard() {
        require_once 'app/views/admin/dashboard.php';
    }

    // Action 2: Kelola Buku (Tambah & Hapus)
    public function kelola_buku() {
        $bukuModel = new BukuModel();
        
        // Handle Tambah
        if (isset($_POST['tambah'])) {
            $bukuModel->tambahBuku($_POST);
            echo "<script>alert('Buku Berhasil Ditambahkan'); window.location='index.php?controller=admin&action=kelola_buku';</script>";
        }
        
        // --- BAGIAN YANG DIPERBAIKI: Handle Hapus (Cek apakah buku sedang dipinjam) ---
        if (isset($_GET['hapus_id'])) {
            require_once __DIR__ . '/../models/PinjamModel.php';
            $pinjamModel = new PinjamModel();
            
            $id_buku = $_GET['hapus_id'];
            
            // Cek apakah buku sedang dipinjam
            if ($pinjamModel->cekBukuDipinjam($id_buku)) {
                // Jika TRUE (sedang dipinjam), tolak penghapusan!
                echo "<script>alert('⛔ GAGAL! Buku tidak bisa dihapus karena masih berstatus SEDANG DIPINJAM oleh anggota.'); window.location='index.php?controller=admin&action=kelola_buku';</script>";
                exit;
            } else {
                // Jika FALSE (aman), lanjutkan penghapusan
                $bukuModel->hapusBuku($id_buku);
                echo "<script>alert('✅ Buku berhasil dihapus dari sistem.'); window.location='index.php?controller=admin&action=kelola_buku';</script>";
                exit;
            }
        }

        $data_buku = $bukuModel->getAllBuku();
        require_once 'app/views/admin/kelola_buku.php';
    }

   public function laporan() {
        $pinjamModel = new PinjamModel();
        
        if (isset($_GET['tgl_awal']) && isset($_GET['tgl_akhir']) && $_GET['tgl_awal'] != '' && $_GET['tgl_akhir'] != '') {
            $tgl_awal = $_GET['tgl_awal'];
            $tgl_akhir = $_GET['tgl_akhir'];
            $data_laporan = $pinjamModel->getLaporan($tgl_awal, $tgl_akhir);
        } else {
            $data_laporan = $pinjamModel->getLaporan(); 
        }
        
        require_once 'app/views/admin/laporan.php';
    }

    public function kelola_anggota() {
        $userModel = new UserModel();

        if (isset($_GET['hapus_id'])) {
            $userModel->hapusUser($_GET['hapus_id']);
            echo "<script>alert('Data Anggota dan Riwayatnya Berhasil Dihapus!'); window.location='index.php?controller=admin&action=kelola_anggota';</script>";
            exit; 
        }

        $data_siswa = $userModel->getAllSiswa();
        require_once 'app/views/admin/kelola_anggota.php';
    }

    // --- BAGIAN YANG DIPERBAIKI (Diubah jadi edit_transaksi) ---
    public function edit_transaksi() {
        $PinjamModel = new PinjamModel();

        // 1. Jika tombol Simpan ditekan
        if (isset($_POST['update'])) {
            $PinjamModel->updatePinjam($_POST);
            echo "<script>alert('Data Peminjaman Berhasil Diupdate!'); window.location='index.php?controller=admin&action=laporan';</script>";
            exit;
        }

        // 2. Ambil data lama untuk ditampilkan di form
        if (isset($_GET['id'])) {
            $data = $PinjamModel->getPinjamById($_GET['id']);
            require_once 'app/views/admin/edit_pinjam.php';
        }
    }

    public function hapus_transaksi() {
        if (isset($_GET['id'])) {
            $PinjamModel = new PinjamModel();
            
            $PinjamModel->hapusPinjam($_GET['id']);
            echo "<script>alert('Riwayat Peminjaman Berhasil Dihapus!'); window.location='index.php?controller=admin&action=laporan';</script>";
            exit;
        }
    }

    public function edit_buku() {
        $bukuModel = new BukuModel();

        // 1. Jika tombol Update ditekan
        if (isset($_POST['update'])) {
            $bukuModel->updateBuku($_POST);
            echo "<script>alert('Data Buku Berhasil Diupdate!'); window.location='index.php?controller=admin&action=kelola_buku';</script>";
        }

        // 2. Ambil data lama untuk ditampilkan
        if (isset($_GET['id'])) {
            $data = $bukuModel->getBukuById($_GET['id']);
            require_once 'app/views/admin/edit_buku.php';
        }
    }

    public function edit_anggota() {
        $userModel = new UserModel();

        // 1. Proses Update
        if (isset($_POST['update'])) {
            $userModel->updateUser($_POST);
            echo "<script>alert('Data Anggota Berhasil Diupdate!'); window.location='index.php?controller=admin&action=kelola_anggota';</script>";
        }

        // 2. Tampilkan Form
        if (isset($_GET['id'])) {
            $data = $userModel->getUserById($_GET['id']);
            require_once 'app/views/admin/edit_anggota.php';
        }
    }

   // GANTI NAMA FUNGSI INI:
    public function kelola_pinjam() {
        require_once __DIR__ . '/../models/PinjamModel.php';
        $pinjamModel = new PinjamModel();
        $data_transaksi = $pinjamModel->getAllTransaksi(); 
        
        // Pastikan nama file view-nya juga sesuai dengan yang kamu simpan
        require_once __DIR__ . '/../views/admin/kelola_pinjam.php';
    }

    // Fungsi untuk menampilkan Form Tambah Pinjam
    public function tambah_pinjam() {
        require_once __DIR__ . '/../models/PinjamModel.php';
        require_once __DIR__ . '/../models/BukuModel.php';
        require_once __DIR__ . '/../models/UserModel.php'; 

        // 1. Jika tombol simpan ditekan
        if (isset($_POST['simpan_pinjam'])) {
            $pinjamModel = new PinjamModel();
            $pinjamModel->tambahPinjam($_POST);
            
            // 👇 BAGIAN INI YANG DIUBAH MENJADI kelola_pinjam 👇
            echo "<script>alert('Berhasil! Buku telah dipinjam.'); window.location='index.php?controller=admin&action=kelola_pinjam';</script>";
            exit;
        }

        // 2. Tarik data buku untuk pilihan di form
        $bukuModel = new BukuModel();
        $data_buku = $bukuModel->getAllBuku();

        // 3. Tarik data SEMUA PENGGUNA menggunakan UserModel (Cara MVC yang Benar)
        $userModel = new UserModel();
        $data_user = $userModel->getAllUser(); 

        // 4. Panggil tampilan form
        require_once __DIR__ . '/../views/admin/tambah_pinjam.php';
    }

    // Fungsi untuk memproses tombol "Kembalikan" di tabel
    public function proses_kembali() {
        if (isset($_GET['id']) && isset($_GET['id_buku'])) {
            require_once __DIR__ . '/../models/PinjamModel.php';
            $pinjamModel = new PinjamModel();
            $pinjamModel->kembalikanBuku($_GET['id'], $_GET['id_buku']);
            
            // 👇 BAGIAN INI JUGA DIUBAH MENJADI kelola_pinjam 👇
            echo "<script>alert('Buku berhasil dikembalikan ke perpustakaan!'); window.location='index.php?controller=admin&action=kelola_pinjam';</script>";
            exit;
        }
    }

}
?>