<?php
session_start();
require_once 'app/config/database.php';

// Ambil controller dan action dari URL
$controllerName = isset($_GET['controller']) ? $_GET['controller'] : 'auth';
$action = isset($_GET['action']) ? $_GET['action'] : 'login';

// Routing
switch($controllerName) {
    case 'auth':
        require_once 'app/controller/AuthController.php';
        $controller = new AuthController();
        break;
    case 'admin':
        require_once 'app/controller/AdminController.php';
        $controller = new AdminController();
        break;
    case 'siswa':
        require_once 'app/controller/SiswaController.php';
        $controller = new SiswaController();
        break;
    default:
        echo "Halaman tidak ditemukan!";
        exit;
}

// Jalankan fungsi (action) di dalam controller
if (method_exists($controller, $action)) {
    $controller->$action();
} else {
    echo "Aksi tidak ditemukan!";
}
?>
