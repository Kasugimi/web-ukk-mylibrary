<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Anggota Baru</title>
    <link rel="stylesheet" href="public/css/bootstrap.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #74ebd5 0%, #ACB6E5 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .card-register {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.2);
            overflow: hidden;
        }
        .card-header {
            background-color: #27ae60; 
            color: white;
            padding: 20px;
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6"> <div class="card card-register">
                    <div class="card-header text-center">
                        <h4>📝 DAFTAR ANGGOTA</h4>
                        <small>Isi data diri untuk membuat akun siswa</small>
                    </div>
                    <div class="card-body p-4 bg-white">
                        
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Nama Lengkap</label>
                                <input type="text" name="nama_lengkap" class="form-control form-control-lg" placeholder="Contoh: Binto Aditya" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-bold">Username</label>
                                <input type="text" name="username" class="form-control form-control-lg" placeholder="Buat username unik" required>
                                <div class="form-text text-muted">Akan digunakan untuk login nanti.</div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-bold">Password</label>
                                <input type="password" name="password" class="form-control form-control-lg" placeholder="********" required>
                            </div>

                            <div class="d-grid gap-2 mt-4">
                                <button type="submit" name="daftar" class="btn btn-success btn-lg">DAFTAR SEKARANG</button>
                            </div>
                        </form>

                        <hr>

                        <div class="text-center mt-3">
                            <p class="mb-0">Sudah punya akun?</p>
                            <a href="index.php?controller=auth&action=login" class="btn btn-outline-secondary btn-sm mt-2">
                                ⬅ Kembali ke Login
                            </a>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html>