<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Perpustakaan</title>
    <link rel="stylesheet" href="public/css/bootstrap.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #74ebd5 0%, #ACB6E5 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .card-login {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.2);
            overflow: hidden;
        }
        .card-header {
            background-color: #2c3e50;
            color: white;
            padding: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <div class="card card-login">
                    <div class="card-header text-center">
                        <h4>📚 MY LIBRARY</h4>
                        <small>Login untuk mengakses layanan</small>
                    </div>
                    <div class="card-body p-4 bg-white">
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Username</label>
                                <input type="text" name="username" class="form-control form-control-lg" placeholder="Masukkan username" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Password</label>
                                <input type="password" name="password" class="form-control form-control-lg" placeholder="********" required>
                            </div>
                            <div class="d-grid gap-2">
                                <button type="submit" name="submit" class="btn btn-primary btn-lg">MASUK SEKARANG</button>
                            </div>
                        </form>
                        <div class="text-center mt-3">
                            <p class="small text-muted">Siswa belum punya akun? <a href="index.php?controller=auth&action=register" class="fw-bold">Daftar Disini</a></p>
                            <p class="small text-muted"><a href="index.php?controller=auth&action=register_admin" class="text-decoration-none">Akses Admin</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>