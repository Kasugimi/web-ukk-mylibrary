<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="public/css/bootstrap.min.css">
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
        <div class="container">
            <a class="navbar-brand fw-bold" href="#">PANEL ADMIN | MY LIBRARY</a>
            <div class="d-flex">
                <a href="index.php?controller=auth&action=logout" class="btn btn-danger btn-sm" onclick="return confirm('Logout sekarang?')">Logout</a>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="alert alert-success shadow-sm">
            <h4>Selamat Datang, Admin! 👋</h4>
            <p class="mb-0">Silakan pilih menu di bawah ini untuk mengelola perpustakaan.</p>
        </div>

        <div class="row mt-4">
            <div class="col-md-6 mb-4">
                <div class="card text-center shadow-sm h-100 border-0">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center py-4">
                        <h1 class="display-4 text-primary">📚</h1>
                        <h5 class="card-title mt-2">Data Buku</h5>
                        <p class="card-text text-muted">Tambah, Edit, dan Hapus Buku.</p>
                        <a href="index.php?controller=admin&action=kelola_buku" class="btn btn-outline-primary stretched-link w-50">Kelola Buku</a>
                    </div>
                </div>
            </div>

            <div class="col-md-6 mb-4">
                <div class="card text-center shadow-sm h-100 border-0">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center py-4">
                        <h1 class="display-4 text-warning">👥</h1>
                        <h5 class="card-title mt-2">Data Anggota</h5>
                        <p class="card-text text-muted">Lihat dan Kelola Data Siswa.</p>
                        <a href="index.php?controller=admin&action=kelola_anggota" class="btn btn-outline-warning stretched-link w-50">Kelola Anggota</a>
                    </div>
                </div>
            </div>

            <div class="col-md-6 mb-4">
                <div class="card text-center shadow-sm h-100 border-0">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center py-4">
                        <h1 class="display-4 text-info">🤝</h1>
                        <h5 class="card-title mt-2">Peminjaman</h5>
                        <p class="card-text text-muted">Peminjaman dan pengembalian.</p>
                        <a href="index.php?controller=admin&action=kelola_transaksi" class="btn btn-outline-info stretched-link w-50">Kelola Transaksi</a>
                    </div>
                </div>
            </div>

            <div class="col-md-6 mb-4">
                <div class="card text-center shadow-sm h-100 border-0">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center py-4">
                        <h1 class="display-4 text-success">📊</h1>
                        <h5 class="card-title mt-2">Laporan Perpustakaan</h5>
                        <p class="card-text text-muted">Cek rekap data.</p>
                        <a href="index.php?controller=admin&action=laporan" class="btn btn-outline-success stretched-link w-50">Lihat Laporan</a>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</body>
</html>
