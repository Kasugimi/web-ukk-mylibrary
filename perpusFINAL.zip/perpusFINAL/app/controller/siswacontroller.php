<?php
require_once 'app/models/BukuModel.php';
require_once 'app/models/PinjamModel.php';

class SiswaController {
    public function __construct() {
        if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'siswa') {
            header("Location: index.php?controller=auth&action=login");
            exit;
        }
    }

    public function dashboard() {
        // highlight di dashboard
        $bukuModel = new BukuModel();
        $data_highlight = $bukuModel->getBukuHighlight();

        require_once 'app/views/siswa/dashboard.php';
    }

    // Katalog & Cari Buku
    public function katalog() {
        $bukuModel = new BukuModel();
        
        if (isset($_GET['cari'])) {
            $data_buku = $bukuModel->cariBuku($_GET['cari']);
        } else {
            $data_buku = $bukuModel->getAllBuku();
        }
        
        require_once 'app/views/siswa/katalog.php';
    }

    // Proses Pinjam Saja (Sesuai arahan Guru)
    public function pinjam() {
        if (isset($_GET['id_buku'])) {
            $id_buku = $_GET['id_buku'];
            $id_user = $_SESSION['user']['id_user'];
            
            $bukuModel = new BukuModel();
            $pinjamModel = new PinjamModel();

            // Cek Stok dulu
            $updateStok = $bukuModel->kurangiStok($id_buku);
            
            if ($updateStok) {
                $pinjamModel->pinjamBuku($id_user, $id_buku);
                // Pesan diubah agar siswa tahu harus ke Admin
                echo "<script>alert('Berhasil meminjam buku! Silakan ambil di meja Admin.'); window.location='index.php?controller=siswa&action=katalog';</script>";
            } else {
                echo "<script>alert('Gagal! Stok buku habis.'); window.location='index.php?controller=siswa&action=katalog';</script>";
            }
        }
    }

    // Halaman Riwayat Saja (Fungsi kembalikan sudah dihapus total)
    public function riwayat() {
        $pinjamModel = new PinjamModel();
        $data_riwayat = $pinjamModel->getRiwayatSiswa($_SESSION['user']['id_user']);
        
        require_once 'app/views/siswa/riwayat.php';
    }
}
?>