<?php

class PinjamModel {
    private $db;

    public function __construct() {
        // Menggunakan koneksi aslimu yang langsung mengarah ke db_perpustakaan_sekolah
        $this->db = new Database();
    }

    // =========================================================
    // 1. TAMPIL SEMUA DATA TRANSAKSI
    // =========================================================
    public function getAllTransaksi() {
        // Kembali menggunakan tabel 'transaksi' dan 'users'
        $query = "SELECT transaksi.*, users.nama_lengkap, buku.judul 
                  FROM transaksi 
                  JOIN users ON transaksi.id_user = users.id_user 
                  JOIN buku ON transaksi.id_buku = buku.id_buku 
                  ORDER BY transaksi.tanggal_pinjam DESC";
                  
        $result = mysqli_query($this->db->koneksi, $query); 
        if (!$result) die("Error Tampil Data: " . mysqli_error($this->db->koneksi));
        
        $data = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = $row;
        }
        return $data;
    }

    // =========================================================
    // 2. SIMPAN PEMINJAMAN BARU
    // =========================================================
    public function tambahPinjam($data) {
        $id_user = $data['id_user'];
        $id_buku = $data['id_buku'];
        $tanggal_pinjam = $data['tanggal_pinjam'];

        $query = "INSERT INTO transaksi (id_user, id_buku, tanggal_pinjam, status) 
                  VALUES ('$id_user', '$id_buku', '$tanggal_pinjam', 'dipinjam')";
        
        $insert = mysqli_query($this->db->koneksi, $query);
        if (!$insert) die("Error Simpan Peminjaman: " . mysqli_error($this->db->koneksi));

        // Kurangi stok buku (-1)
        $queryStok = "UPDATE buku SET stok = stok - 1 WHERE id_buku = '$id_buku'";
        mysqli_query($this->db->koneksi, $queryStok);
        return true;
    }

    // =========================================================
    // 3. PROSES PENGEMBALIAN BUKU
    // =========================================================
    public function kembalikanBuku($id_transaksi, $id_buku) {
        $tanggal_kembali = date('Y-m-d');
        
        $query = "UPDATE transaksi SET tanggal_kembali = '$tanggal_kembali', status = 'kembali' 
                  WHERE id_transaksi = '$id_transaksi'";
        
        $update = mysqli_query($this->db->koneksi, $query);
        if (!$update) die("Error Kembalikan Buku: " . mysqli_error($this->db->koneksi));

        // Tambah stok buku (+1)
        $queryStok = "UPDATE buku SET stok = stok + 1 WHERE id_buku = '$id_buku'";
        mysqli_query($this->db->koneksi, $queryStok);
        return true;
    }

    // =========================================================
    // 4. AMBIL DATA UNTUK LAPORAN
    // =========================================================
    public function getLaporan($tgl_awal = '', $tgl_akhir = '') {
        $query = "SELECT transaksi.*, users.nama_lengkap, buku.judul 
                  FROM transaksi 
                  JOIN users ON transaksi.id_user = users.id_user 
                  JOIN buku ON transaksi.id_buku = buku.id_buku";
        
        if ($tgl_awal != '' && $tgl_akhir != '') {
            $query .= " WHERE transaksi.tanggal_pinjam BETWEEN '$tgl_awal' AND '$tgl_akhir'";
        }
        
        $query .= " ORDER BY transaksi.tanggal_pinjam DESC";

        $result = mysqli_query($this->db->koneksi, $query);
        if (!$result) die("Error Laporan: " . mysqli_error($this->db->koneksi));

        $data = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = $row;
        }
        return $data;
    }

    // =========================================================
    // 5. AMBIL SATU DATA UNTUK FORM EDIT
    // =========================================================
    public function getPinjamById($id) {
        $query = "SELECT transaksi.*, users.nama_lengkap, buku.judul 
                  FROM transaksi 
                  JOIN users ON transaksi.id_user = users.id_user 
                  JOIN buku ON transaksi.id_buku = buku.id_buku 
                  WHERE transaksi.id_transaksi = '$id'";
                  
        $result = mysqli_query($this->db->koneksi, $query);
        return mysqli_fetch_assoc($result);
    }

    // =========================================================
    // 6. UPDATE / SIMPAN HASIL EDIT
    // =========================================================
    public function updatePinjam($data) {
        $id_transaksi = $data['id_transaksi'];
        $tanggal_kembali = $data['tanggal_kembali'];
        $status = $data['status'];

        $query = "UPDATE transaksi SET 
                  tanggal_kembali = '$tanggal_kembali', 
                  status = '$status' 
                  WHERE id_transaksi = '$id_transaksi'";
                  
        return mysqli_query($this->db->koneksi, $query);
    }

    // =========================================================
    // 7. HAPUS RIWAYAT PEMINJAMAN
    // =========================================================
    public function hapusPinjam($id) {
        $query = "DELETE FROM transaksi WHERE id_transaksi = '$id'";
        return mysqli_query($this->db->koneksi, $query);
    }
    // =========================================================
    // FUNGSI UNTUK SISWA: Meminjam buku dari halaman katalog
    // =========================================================
    // Kita tambah "= null" agar parameter ke-3 tidak wajib diisi
    public function pinjamBuku($id_user, $id_buku, $tanggal_pinjam = null) {
        
        // JIKA TANGGAL KOSONG (karena Controller cuma kirim 2 data), 
        // MAKA OTOMATIS ISI DENGAN TANGGAL HARI INI
        if ($tanggal_pinjam === null) {
            $tanggal_pinjam = date('Y-m-d');
        }

        $id_u = mysqli_real_escape_string($this->db->koneksi, $id_user);
        $id_b = mysqli_real_escape_string($this->db->koneksi, $id_buku);
        
        // Pastikan nama tabelnya 'transaksi' sesuai penemuan kita tadi
        $query = "INSERT INTO transaksi (id_user, id_buku, tanggal_pinjam, status) 
                  VALUES ('$id_u', '$id_b', '$tanggal_pinjam', 'dipinjam')";
        
        $insert = mysqli_query($this->db->koneksi, $query);

        if ($insert) {
            // Kurangi stok buku
            $queryStok = "UPDATE buku SET stok = stok - 1 WHERE id_buku = '$id_b'";
            mysqli_query($this->db->koneksi, $queryStok);
            return true;
        }
        return false;
    }
    
    // FUNGSI UNTUK SISWA: Mengambil riwayat pinjam milik sendiri
    // =========================================================
    public function getRiwayatSiswa($id_user) {
        // Amankan ID user
        $id = mysqli_real_escape_string($this->db->koneksi, $id_user);
        
        // Query JOIN untuk mengambil data transaksi dan judul buku
        // Kita filter berdasarkan ID Siswa yang sedang login
        $query = "SELECT transaksi.*, buku.judul 
                  FROM transaksi 
                  JOIN buku ON transaksi.id_buku = buku.id_buku 
                  WHERE transaksi.id_user = '$id' 
                  ORDER BY transaksi.tanggal_pinjam DESC";
                  
        $result = mysqli_query($this->db->koneksi, $query);
        
        $data = [];
        if ($result) {
            while ($row = mysqli_fetch_assoc($result)) {
                $data[] = $row;
            }
        }
        return $data;
    }

    
}
?>
